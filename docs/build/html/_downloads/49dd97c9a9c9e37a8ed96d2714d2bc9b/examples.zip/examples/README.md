# Basic examples

This folder contains some basic examples of Tesseract usage, tested regularly to ensure they work with the latest version of Tesseract.

Looking for more advanced tutorials? Check out our [official tutorials](https://si-tesseract.discourse.group/c/showcase/tutorials/12) and [how-to guides](https://si-tesseract.discourse.group/c/support/how-to-guides/10).
