# Build a Tesseract with Local Dependencies

See: [Read the docs](https://docs.pasteurlabs.ai/projects/tesseract-core/howto/)
